var searchData = [{
    "land": "Đất nền Quận 1",
    "home": "Nhà ở Quận 1",
    "apartment": "Chung cư Quận 1"
  },
  {
    "land": "Đất nền Quận 2",
    "home": "Nhà ở Quận 2",
    "apartment": "Chung cư Quận 2"
  },
  {
    "land": "Đất nền Quận 3",
    "home": "Nhà ở Quận 3",
    "apartment": "Chung cư Quận 3"
  },
  {
    "land": "Đất nền Quận 4",
    "home": "Nhà ở Quận 4",
    "apartment": "Chung cư Quận 4"
  },
  {
    "land": "Đất nền Quận 5",
    "home": "Nhà ở Quận 5",
    "apartment": "Chung cư Quận 5"
  },
  {
    "land": "Đất nền Quận 6",
    "home": "Nhà ở Quận 6",
    "apartment": "Chung cư Quận 6"
  },
  {
    "land": "Bất động sản khu vực quận Bình Thạnh",
    "home": "Nhà ở khu vực quận Bình Thạnh",
    "apartment": "Chung cư khu vực quận Bình Thạnh"
  }
]