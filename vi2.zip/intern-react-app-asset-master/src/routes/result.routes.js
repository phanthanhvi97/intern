import News from '../pages/News';

export const routes = [
  {
    exact: true,
    path: '/result/news',
    component: News,
  }
];