export default {
  baseURL: 'http://192.168.1.240:9002/api/v1',
};